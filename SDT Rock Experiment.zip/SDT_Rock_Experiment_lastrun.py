﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2026.2.3),
    on September 05, 2026, at 23:17
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard
import psychopy.hardware.speaker

# set audio backend
sound.Sound.backend = prefs.hardware['audioLib']
hardware.speaker.SpeakerDevice.backend = prefs.hardware['audioLib']
# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2026.2.3'
expName = 'SDT_Rock_Experiment'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = (1024, 768)
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = 'data/' + expInfo['participant'] + '_' + expName + '_' + expInfo['date']
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\SDT_Rock_Experiment\\SDT_Rock_Experiment_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    # store pilot mode in data file
    thisExp.addData('piloting', PILOTING, priority=priority.LOW)
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color=(-1.0000, -1.0000, 0.0039), colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = (-1.0000, -1.0000, 0.0039)
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "Instructions" ---
    instructions_text = visual.TextStim(win=win, name='instructions_text',
        text='AUDITORY DETECTION EXPERIMENT\n\nYou will listen to short rock-music clips through headphones.\n\nSome clips contain a hidden sound.\nOther clips contain no hidden sound.\n\nAfter each clip:\n\nPress Y if you heard the hidden sound.\nPress N if you did not hear it.\n\nThe hidden sound may be very difficult to hear.\nIf you are unsure, make your best judgment.\n\nKeep the headphone volume constant throughout.\n\nPress SPACE to begin.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_instResp = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "PracticeIntro" ---
    text_practiceIntro = visual.TextStim(win=win, name='text_practiceIntro',
        text='PRACTICE ROUND\n\nYou will now complete a few practice trials.\n\nThese trials are only to familiarize you with the task\nand will not be included in your final results.\n\nPress SPACE to begin.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_practiceIntro = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "PracticeTrial" ---
    sound_1 = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker=None,    name='sound_1'
    )
    sound_1.setVolume(1.0)
    key_ansResp = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    text_answerPrompt = visual.TextStim(win=win, name='text_answerPrompt',
        text='Did you hear the hidden sound?\n\nY = Yes        N = No',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "PracticeFeedback" ---
    text_practiceFeedback = visual.TextStim(win=win, name='text_practiceFeedback',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_feedback = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "ExperimentIntro" ---
    text_experimentIntro = visual.TextStim(win=win, name='text_experimentIntro',
        text='ACTUAL EXPERIMENT\n\nThe practice round is complete.\n\nYou will now complete the actual experiment.\nYour responses in these trials will be used for your final results.\n\nPress SPACE to begin.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_experimentIntro = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "ExperimentalTrial" ---
    sound_exp = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker=None,    name='sound_exp'
    )
    sound_exp.setVolume(1.0)
    key_expResp = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    # Run 'Begin Experiment' code from SDT_Code
    hits = 0
    misses = 0
    false_alarms = 0
    correct_rejections = 0
    text_expAnswerPrompt = visual.TextStim(win=win, name='text_expAnswerPrompt',
        text='Did you hear the hidden sound?\n\nY = Yes        N = No',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "Results" ---
    text_Results = visual.TextStim(win=win, name='text_Results',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_Results = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "ThankYou" ---
    text_thankYou = visual.TextStim(win=win, name='text_thankYou',
        text='Thank you for participating!\n\nYou have completed the experiment.\nPress SPACE to exit.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_thankYou = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "Instructions" ---
    # create an object to store info about Routine Instructions
    Instructions = data.Routine(
        name='Instructions',
        components=[instructions_text, key_instResp],
    )
    Instructions.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_instResp
    key_instResp.keys = []
    key_instResp.rt = []
    _key_instResp_allKeys = []
    # store start times for Instructions
    Instructions.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Instructions.tStart = globalClock.getTime(format='float')
    Instructions.status = STARTED
    thisExp.addData('Instructions.started', Instructions.tStart)
    Instructions.maxDuration = None
    # keep track of which components have finished
    InstructionsComponents = Instructions.components
    for thisComponent in Instructions.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instructions" ---
    thisExp.currentRoutine = Instructions
    Instructions.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instructions_text* updates
        
        # if instructions_text is starting this frame...
        if instructions_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instructions_text.frameNStart = frameN  # exact frame index
            instructions_text.tStart = t  # local t and not account for scr refresh
            instructions_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instructions_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instructions_text.started')
            # update status
            instructions_text.status = STARTED
            instructions_text.setAutoDraw(True)
        
        # if instructions_text is active this frame...
        if instructions_text.status == STARTED:
            # update params
            pass
        
        # *key_instResp* updates
        waitOnFlip = False
        
        # if key_instResp is starting this frame...
        if key_instResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_instResp.frameNStart = frameN  # exact frame index
            key_instResp.tStart = t  # local t and not account for scr refresh
            key_instResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_instResp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_instResp.started')
            # update status
            key_instResp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_instResp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_instResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_instResp.status == STARTED and not waitOnFlip:
            theseKeys = key_instResp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_instResp_allKeys.extend(theseKeys)
            if len(_key_instResp_allKeys):
                key_instResp.keys = _key_instResp_allKeys[-1].name  # just the last key pressed
                key_instResp.rt = _key_instResp_allKeys[-1].rt
                key_instResp.duration = _key_instResp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Instructions,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Instructions.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Instructions.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Instructions.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instructions" ---
    for thisComponent in Instructions.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Instructions
    Instructions.tStop = globalClock.getTime(format='float')
    Instructions.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Instructions.stopped', Instructions.tStop)
    # check responses
    if key_instResp.keys in ['', [], None]:  # No response was made
        key_instResp.keys = None
    thisExp.addData('key_instResp.keys',key_instResp.keys)
    if key_instResp.keys != None:  # we had a response
        thisExp.addData('key_instResp.rt', key_instResp.rt)
        thisExp.addData('key_instResp.duration', key_instResp.duration)
    thisExp.nextEntry()
    # the Routine "Instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "PracticeIntro" ---
    # create an object to store info about Routine PracticeIntro
    PracticeIntro = data.Routine(
        name='PracticeIntro',
        components=[text_practiceIntro, key_practiceIntro],
    )
    PracticeIntro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_practiceIntro
    key_practiceIntro.keys = []
    key_practiceIntro.rt = []
    _key_practiceIntro_allKeys = []
    # store start times for PracticeIntro
    PracticeIntro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    PracticeIntro.tStart = globalClock.getTime(format='float')
    PracticeIntro.status = STARTED
    thisExp.addData('PracticeIntro.started', PracticeIntro.tStart)
    PracticeIntro.maxDuration = None
    # keep track of which components have finished
    PracticeIntroComponents = PracticeIntro.components
    for thisComponent in PracticeIntro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "PracticeIntro" ---
    thisExp.currentRoutine = PracticeIntro
    PracticeIntro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_practiceIntro* updates
        
        # if text_practiceIntro is starting this frame...
        if text_practiceIntro.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_practiceIntro.frameNStart = frameN  # exact frame index
            text_practiceIntro.tStart = t  # local t and not account for scr refresh
            text_practiceIntro.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_practiceIntro, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_practiceIntro.started')
            # update status
            text_practiceIntro.status = STARTED
            text_practiceIntro.setAutoDraw(True)
        
        # if text_practiceIntro is active this frame...
        if text_practiceIntro.status == STARTED:
            # update params
            pass
        
        # *key_practiceIntro* updates
        waitOnFlip = False
        
        # if key_practiceIntro is starting this frame...
        if key_practiceIntro.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_practiceIntro.frameNStart = frameN  # exact frame index
            key_practiceIntro.tStart = t  # local t and not account for scr refresh
            key_practiceIntro.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_practiceIntro, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_practiceIntro.started')
            # update status
            key_practiceIntro.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_practiceIntro.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_practiceIntro.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_practiceIntro.status == STARTED and not waitOnFlip:
            theseKeys = key_practiceIntro.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_practiceIntro_allKeys.extend(theseKeys)
            if len(_key_practiceIntro_allKeys):
                key_practiceIntro.keys = _key_practiceIntro_allKeys[-1].name  # just the last key pressed
                key_practiceIntro.rt = _key_practiceIntro_allKeys[-1].rt
                key_practiceIntro.duration = _key_practiceIntro_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=PracticeIntro,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            PracticeIntro.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if PracticeIntro.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in PracticeIntro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "PracticeIntro" ---
    for thisComponent in PracticeIntro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for PracticeIntro
    PracticeIntro.tStop = globalClock.getTime(format='float')
    PracticeIntro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('PracticeIntro.stopped', PracticeIntro.tStop)
    # check responses
    if key_practiceIntro.keys in ['', [], None]:  # No response was made
        key_practiceIntro.keys = None
    thisExp.addData('key_practiceIntro.keys',key_practiceIntro.keys)
    if key_practiceIntro.keys != None:  # we had a response
        thisExp.addData('key_practiceIntro.rt', key_practiceIntro.rt)
        thisExp.addData('key_practiceIntro.duration', key_practiceIntro.duration)
    thisExp.nextEntry()
    # the Routine "PracticeIntro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    PracticeLoop = data.TrialHandler2(
        name='PracticeLoop',
        nReps=1, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('practice_conditions.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(PracticeLoop)  # add the loop to the experiment
    thisPracticeLoop = PracticeLoop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPracticeLoop.rgb)
    if thisPracticeLoop != None:
        for paramName in thisPracticeLoop:
            globals()[paramName] = thisPracticeLoop[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisPracticeLoop in PracticeLoop:
        PracticeLoop.status = STARTED
        if hasattr(thisPracticeLoop, 'status'):
            thisPracticeLoop.status = STARTED
        currentLoop = PracticeLoop
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisPracticeLoop.rgb)
        if thisPracticeLoop != None:
            for paramName in thisPracticeLoop:
                globals()[paramName] = thisPracticeLoop[paramName]
        
        # --- Prepare to start Routine "PracticeTrial" ---
        # create an object to store info about Routine PracticeTrial
        PracticeTrial = data.Routine(
            name='PracticeTrial',
            components=[sound_1, key_ansResp, text_answerPrompt],
        )
        PracticeTrial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        sound_1.setSound(practiceSoundFile, hamming=True)
        sound_1.setVolume(1.0, log=False)
        sound_1.seek(0)
        # create starting attributes for key_ansResp
        key_ansResp.keys = []
        key_ansResp.rt = []
        _key_ansResp_allKeys = []
        # store start times for PracticeTrial
        PracticeTrial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        PracticeTrial.tStart = globalClock.getTime(format='float')
        PracticeTrial.status = STARTED
        thisExp.addData('PracticeTrial.started', PracticeTrial.tStart)
        PracticeTrial.maxDuration = None
        # keep track of which components have finished
        PracticeTrialComponents = PracticeTrial.components
        for thisComponent in PracticeTrial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "PracticeTrial" ---
        thisExp.currentRoutine = PracticeTrial
        PracticeTrial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisPracticeLoop, 'status') and thisPracticeLoop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *sound_1* updates
            
            # if sound_1 is starting this frame...
            if sound_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sound_1.frameNStart = frameN  # exact frame index
                sound_1.tStart = t  # local t and not account for scr refresh
                sound_1.tStartRefresh = tThisFlipGlobal  # on global time
                # add timestamp to datafile
                thisExp.addData('sound_1.started', tThisFlipGlobal)
                # update status
                sound_1.status = STARTED
                sound_1.play(when=win)  # sync with win flip
            
            # if sound_1 is stopping this frame...
            if sound_1.status == STARTED:
                if bool(False) or sound_1.isFinished:
                    # keep track of stop time/frame for later
                    sound_1.tStop = t  # not accounting for scr refresh
                    sound_1.tStopRefresh = tThisFlipGlobal  # on global time
                    sound_1.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'sound_1.stopped')
                    # update status
                    sound_1.status = FINISHED
                    sound_1.stop()
            
            # *key_ansResp* updates
            waitOnFlip = False
            
            # if key_ansResp is starting this frame...
            if key_ansResp.status == NOT_STARTED and tThisFlip >= 4.0-frameTolerance:
                # keep track of start time/frame for later
                key_ansResp.frameNStart = frameN  # exact frame index
                key_ansResp.tStart = t  # local t and not account for scr refresh
                key_ansResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_ansResp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_ansResp.started')
                # update status
                key_ansResp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_ansResp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_ansResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_ansResp.status == STARTED and not waitOnFlip:
                theseKeys = key_ansResp.getKeys(keyList=['y','n'], ignoreKeys=["escape"], waitRelease=False)
                _key_ansResp_allKeys.extend(theseKeys)
                if len(_key_ansResp_allKeys):
                    key_ansResp.keys = _key_ansResp_allKeys[-1].name  # just the last key pressed
                    key_ansResp.rt = _key_ansResp_allKeys[-1].rt
                    key_ansResp.duration = _key_ansResp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_answerPrompt* updates
            
            # if text_answerPrompt is starting this frame...
            if text_answerPrompt.status == NOT_STARTED and tThisFlip >= 4.0-frameTolerance:
                # keep track of start time/frame for later
                text_answerPrompt.frameNStart = frameN  # exact frame index
                text_answerPrompt.tStart = t  # local t and not account for scr refresh
                text_answerPrompt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_answerPrompt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_answerPrompt.started')
                # update status
                text_answerPrompt.status = STARTED
                text_answerPrompt.setAutoDraw(True)
            
            # if text_answerPrompt is active this frame...
            if text_answerPrompt.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=PracticeTrial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                PracticeTrial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if PracticeTrial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in PracticeTrial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "PracticeTrial" ---
        for thisComponent in PracticeTrial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for PracticeTrial
        PracticeTrial.tStop = globalClock.getTime(format='float')
        PracticeTrial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('PracticeTrial.stopped', PracticeTrial.tStop)
        sound_1.pause()  # ensure sound has stopped at end of Routine
        # check responses
        if key_ansResp.keys in ['', [], None]:  # No response was made
            key_ansResp.keys = None
        PracticeLoop.addData('key_ansResp.keys',key_ansResp.keys)
        if key_ansResp.keys != None:  # we had a response
            PracticeLoop.addData('key_ansResp.rt', key_ansResp.rt)
            PracticeLoop.addData('key_ansResp.duration', key_ansResp.duration)
        # the Routine "PracticeTrial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "PracticeFeedback" ---
        # create an object to store info about Routine PracticeFeedback
        PracticeFeedback = data.Routine(
            name='PracticeFeedback',
            components=[text_practiceFeedback, key_feedback],
        )
        PracticeFeedback.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_feedback
        # Determine the correct answer for this practice trial
        if signal == 1:
            correct_answer = "YES - The hidden sound was present."
        else:
            correct_answer = "NO - There was no hidden sound."
        
        # Get the participant's response
        if key_ansResp.keys:
            participant_answer = key_ansResp.keys[-1].upper()
        
            if participant_answer == 'Y':
                participant_response = "YES"
            elif participant_answer == 'N':
                participant_response = "NO"
            else:
                participant_response = "No response"
        else:
            participant_response = "No response"
        
        # Create feedback message
        feedbackText = f"""PRACTICE FEEDBACK
        
        Your response: {participant_response}
        
        Correct answer:
        {correct_answer}
        
        Press SPACE to continue."""
        text_practiceFeedback.setText(feedbackText)
        # create starting attributes for key_feedback
        key_feedback.keys = []
        key_feedback.rt = []
        _key_feedback_allKeys = []
        # store start times for PracticeFeedback
        PracticeFeedback.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        PracticeFeedback.tStart = globalClock.getTime(format='float')
        PracticeFeedback.status = STARTED
        thisExp.addData('PracticeFeedback.started', PracticeFeedback.tStart)
        PracticeFeedback.maxDuration = None
        # keep track of which components have finished
        PracticeFeedbackComponents = PracticeFeedback.components
        for thisComponent in PracticeFeedback.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "PracticeFeedback" ---
        thisExp.currentRoutine = PracticeFeedback
        PracticeFeedback.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisPracticeLoop, 'status') and thisPracticeLoop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_practiceFeedback* updates
            
            # if text_practiceFeedback is starting this frame...
            if text_practiceFeedback.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_practiceFeedback.frameNStart = frameN  # exact frame index
                text_practiceFeedback.tStart = t  # local t and not account for scr refresh
                text_practiceFeedback.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_practiceFeedback, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_practiceFeedback.started')
                # update status
                text_practiceFeedback.status = STARTED
                text_practiceFeedback.setAutoDraw(True)
            
            # if text_practiceFeedback is active this frame...
            if text_practiceFeedback.status == STARTED:
                # update params
                pass
            
            # *key_feedback* updates
            waitOnFlip = False
            
            # if key_feedback is starting this frame...
            if key_feedback.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_feedback.frameNStart = frameN  # exact frame index
                key_feedback.tStart = t  # local t and not account for scr refresh
                key_feedback.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_feedback, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_feedback.started')
                # update status
                key_feedback.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_feedback.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_feedback.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_feedback.status == STARTED and not waitOnFlip:
                theseKeys = key_feedback.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_feedback_allKeys.extend(theseKeys)
                if len(_key_feedback_allKeys):
                    key_feedback.keys = _key_feedback_allKeys[-1].name  # just the last key pressed
                    key_feedback.rt = _key_feedback_allKeys[-1].rt
                    key_feedback.duration = _key_feedback_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=PracticeFeedback,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                PracticeFeedback.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if PracticeFeedback.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in PracticeFeedback.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "PracticeFeedback" ---
        for thisComponent in PracticeFeedback.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for PracticeFeedback
        PracticeFeedback.tStop = globalClock.getTime(format='float')
        PracticeFeedback.tStopRefresh = tThisFlipGlobal
        thisExp.addData('PracticeFeedback.stopped', PracticeFeedback.tStop)
        # check responses
        if key_feedback.keys in ['', [], None]:  # No response was made
            key_feedback.keys = None
        PracticeLoop.addData('key_feedback.keys',key_feedback.keys)
        if key_feedback.keys != None:  # we had a response
            PracticeLoop.addData('key_feedback.rt', key_feedback.rt)
            PracticeLoop.addData('key_feedback.duration', key_feedback.duration)
        # the Routine "PracticeFeedback" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisPracticeLoop as finished
        if hasattr(thisPracticeLoop, 'status'):
            thisPracticeLoop.status = FINISHED
        # if awaiting a pause, pause now
        if PracticeLoop.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            PracticeLoop.status = STARTED
        thisExp.nextEntry()
        
    # completed 1 repeats of 'PracticeLoop'
    PracticeLoop.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "ExperimentIntro" ---
    # create an object to store info about Routine ExperimentIntro
    ExperimentIntro = data.Routine(
        name='ExperimentIntro',
        components=[text_experimentIntro, key_experimentIntro],
    )
    ExperimentIntro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_experimentIntro
    key_experimentIntro.keys = []
    key_experimentIntro.rt = []
    _key_experimentIntro_allKeys = []
    # store start times for ExperimentIntro
    ExperimentIntro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    ExperimentIntro.tStart = globalClock.getTime(format='float')
    ExperimentIntro.status = STARTED
    thisExp.addData('ExperimentIntro.started', ExperimentIntro.tStart)
    ExperimentIntro.maxDuration = None
    # keep track of which components have finished
    ExperimentIntroComponents = ExperimentIntro.components
    for thisComponent in ExperimentIntro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "ExperimentIntro" ---
    thisExp.currentRoutine = ExperimentIntro
    ExperimentIntro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_experimentIntro* updates
        
        # if text_experimentIntro is starting this frame...
        if text_experimentIntro.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_experimentIntro.frameNStart = frameN  # exact frame index
            text_experimentIntro.tStart = t  # local t and not account for scr refresh
            text_experimentIntro.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_experimentIntro, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_experimentIntro.started')
            # update status
            text_experimentIntro.status = STARTED
            text_experimentIntro.setAutoDraw(True)
        
        # if text_experimentIntro is active this frame...
        if text_experimentIntro.status == STARTED:
            # update params
            pass
        
        # *key_experimentIntro* updates
        waitOnFlip = False
        
        # if key_experimentIntro is starting this frame...
        if key_experimentIntro.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_experimentIntro.frameNStart = frameN  # exact frame index
            key_experimentIntro.tStart = t  # local t and not account for scr refresh
            key_experimentIntro.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_experimentIntro, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_experimentIntro.started')
            # update status
            key_experimentIntro.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_experimentIntro.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_experimentIntro.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_experimentIntro.status == STARTED and not waitOnFlip:
            theseKeys = key_experimentIntro.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_experimentIntro_allKeys.extend(theseKeys)
            if len(_key_experimentIntro_allKeys):
                key_experimentIntro.keys = _key_experimentIntro_allKeys[-1].name  # just the last key pressed
                key_experimentIntro.rt = _key_experimentIntro_allKeys[-1].rt
                key_experimentIntro.duration = _key_experimentIntro_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=ExperimentIntro,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            ExperimentIntro.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if ExperimentIntro.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in ExperimentIntro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "ExperimentIntro" ---
    for thisComponent in ExperimentIntro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for ExperimentIntro
    ExperimentIntro.tStop = globalClock.getTime(format='float')
    ExperimentIntro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('ExperimentIntro.stopped', ExperimentIntro.tStop)
    # check responses
    if key_experimentIntro.keys in ['', [], None]:  # No response was made
        key_experimentIntro.keys = None
    thisExp.addData('key_experimentIntro.keys',key_experimentIntro.keys)
    if key_experimentIntro.keys != None:  # we had a response
        thisExp.addData('key_experimentIntro.rt', key_experimentIntro.rt)
        thisExp.addData('key_experimentIntro.duration', key_experimentIntro.duration)
    thisExp.nextEntry()
    # the Routine "ExperimentIntro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    ExperimentalLoop = data.TrialHandler2(
        name='ExperimentalLoop',
        nReps=1, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('experimental_conditions.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(ExperimentalLoop)  # add the loop to the experiment
    thisExperimentalLoop = ExperimentalLoop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisExperimentalLoop.rgb)
    if thisExperimentalLoop != None:
        for paramName in thisExperimentalLoop:
            globals()[paramName] = thisExperimentalLoop[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisExperimentalLoop in ExperimentalLoop:
        ExperimentalLoop.status = STARTED
        if hasattr(thisExperimentalLoop, 'status'):
            thisExperimentalLoop.status = STARTED
        currentLoop = ExperimentalLoop
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisExperimentalLoop.rgb)
        if thisExperimentalLoop != None:
            for paramName in thisExperimentalLoop:
                globals()[paramName] = thisExperimentalLoop[paramName]
        
        # --- Prepare to start Routine "ExperimentalTrial" ---
        # create an object to store info about Routine ExperimentalTrial
        ExperimentalTrial = data.Routine(
            name='ExperimentalTrial',
            components=[sound_exp, key_expResp, text_expAnswerPrompt],
        )
        ExperimentalTrial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        sound_exp.setSound(soundFile, hamming=True)
        sound_exp.setVolume(1.0, log=False)
        sound_exp.seek(0)
        # create starting attributes for key_expResp
        key_expResp.keys = []
        key_expResp.rt = []
        _key_expResp_allKeys = []
        # store start times for ExperimentalTrial
        ExperimentalTrial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        ExperimentalTrial.tStart = globalClock.getTime(format='float')
        ExperimentalTrial.status = STARTED
        thisExp.addData('ExperimentalTrial.started', ExperimentalTrial.tStart)
        ExperimentalTrial.maxDuration = None
        # keep track of which components have finished
        ExperimentalTrialComponents = ExperimentalTrial.components
        for thisComponent in ExperimentalTrial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "ExperimentalTrial" ---
        thisExp.currentRoutine = ExperimentalTrial
        ExperimentalTrial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisExperimentalLoop, 'status') and thisExperimentalLoop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *sound_exp* updates
            
            # if sound_exp is starting this frame...
            if sound_exp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sound_exp.frameNStart = frameN  # exact frame index
                sound_exp.tStart = t  # local t and not account for scr refresh
                sound_exp.tStartRefresh = tThisFlipGlobal  # on global time
                # add timestamp to datafile
                thisExp.addData('sound_exp.started', tThisFlipGlobal)
                # update status
                sound_exp.status = STARTED
                sound_exp.play(when=win)  # sync with win flip
            
            # if sound_exp is stopping this frame...
            if sound_exp.status == STARTED:
                if bool(False) or sound_exp.isFinished:
                    # keep track of stop time/frame for later
                    sound_exp.tStop = t  # not accounting for scr refresh
                    sound_exp.tStopRefresh = tThisFlipGlobal  # on global time
                    sound_exp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'sound_exp.stopped')
                    # update status
                    sound_exp.status = FINISHED
                    sound_exp.stop()
            
            # *key_expResp* updates
            waitOnFlip = False
            
            # if key_expResp is starting this frame...
            if key_expResp.status == NOT_STARTED and tThisFlip >= 4.0-frameTolerance:
                # keep track of start time/frame for later
                key_expResp.frameNStart = frameN  # exact frame index
                key_expResp.tStart = t  # local t and not account for scr refresh
                key_expResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_expResp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_expResp.started')
                # update status
                key_expResp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_expResp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_expResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_expResp.status == STARTED and not waitOnFlip:
                theseKeys = key_expResp.getKeys(keyList=['y','n'], ignoreKeys=["escape"], waitRelease=False)
                _key_expResp_allKeys.extend(theseKeys)
                if len(_key_expResp_allKeys):
                    key_expResp.keys = _key_expResp_allKeys[-1].name  # just the last key pressed
                    key_expResp.rt = _key_expResp_allKeys[-1].rt
                    key_expResp.duration = _key_expResp_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_expAnswerPrompt* updates
            
            # if text_expAnswerPrompt is starting this frame...
            if text_expAnswerPrompt.status == NOT_STARTED and tThisFlip >= 4.0-frameTolerance:
                # keep track of start time/frame for later
                text_expAnswerPrompt.frameNStart = frameN  # exact frame index
                text_expAnswerPrompt.tStart = t  # local t and not account for scr refresh
                text_expAnswerPrompt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_expAnswerPrompt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_expAnswerPrompt.started')
                # update status
                text_expAnswerPrompt.status = STARTED
                text_expAnswerPrompt.setAutoDraw(True)
            
            # if text_expAnswerPrompt is active this frame...
            if text_expAnswerPrompt.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=ExperimentalTrial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                ExperimentalTrial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if ExperimentalTrial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in ExperimentalTrial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "ExperimentalTrial" ---
        for thisComponent in ExperimentalTrial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for ExperimentalTrial
        ExperimentalTrial.tStop = globalClock.getTime(format='float')
        ExperimentalTrial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('ExperimentalTrial.stopped', ExperimentalTrial.tStop)
        sound_exp.pause()  # ensure sound has stopped at end of Routine
        # check responses
        if key_expResp.keys in ['', [], None]:  # No response was made
            key_expResp.keys = None
        ExperimentalLoop.addData('key_expResp.keys',key_expResp.keys)
        if key_expResp.keys != None:  # we had a response
            ExperimentalLoop.addData('key_expResp.rt', key_expResp.rt)
            ExperimentalLoop.addData('key_expResp.duration', key_expResp.duration)
        # Run 'End Routine' code from SDT_Code
        if key_expResp.keys:
            response = key_expResp.keys[-1]
        
            if signal == 1:
                if response == 'y':
                    hits += 1
                elif response == 'n':
                    misses += 1
        
            elif signal == 0:
                if response == 'y':
                    false_alarms += 1
                elif response == 'n':
                    correct_rejections += 1
        # the Routine "ExperimentalTrial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisExperimentalLoop as finished
        if hasattr(thisExperimentalLoop, 'status'):
            thisExperimentalLoop.status = FINISHED
        # if awaiting a pause, pause now
        if ExperimentalLoop.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            ExperimentalLoop.status = STARTED
        thisExp.nextEntry()
        
    # completed 1 repeats of 'ExperimentalLoop'
    ExperimentalLoop.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "Results" ---
    # create an object to store info about Routine Results
    Results = data.Routine(
        name='Results',
        components=[text_Results, key_Results],
    )
    Results.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from ResultsCode
    from scipy.stats import norm
    
    # Raw observed rates
    raw_hit_rate = hits / (hits + misses)
    raw_false_alarm_rate = false_alarms / (false_alarms + correct_rejections)
    
    # Adjust rates only for d′ and criterion calculation
    hit_rate = (hits + 0.5) / (hits + misses + 1)
    false_alarm_rate = (false_alarms + 0.5) / (false_alarms + correct_rejections + 1)
    
    # Signal Detection Theory measures
    d_prime = norm.ppf(hit_rate) - norm.ppf(false_alarm_rate)
    
    criterion_c = -(norm.ppf(hit_rate) + norm.ppf(false_alarm_rate)) / 2
    
    # F1-score
    precision = hits / (hits + false_alarms) if (hits + false_alarms) > 0 else 0
    recall = hits / (hits + misses) if (hits + misses) > 0 else 0
    
    if (precision + recall) > 0:
        f1_score = 2 * precision * recall / (precision + recall)
    else:
        f1_score = 0
    
    # Save final results
    thisExp.addData('Hits', hits)
    thisExp.addData('Misses', misses)
    thisExp.addData('FalseAlarms', false_alarms)
    thisExp.addData('CorrectRejections', correct_rejections)
    
    thisExp.addData('HitRate', raw_hit_rate)
    thisExp.addData('FalseAlarmRate', raw_false_alarm_rate)
    thisExp.addData('d_prime', d_prime)
    thisExp.addData('criterion_c', criterion_c)
    thisExp.addData('F1_score', f1_score)
    
    results_text = f"""YOUR RESULTS
    
    Hits: {hits}
    Misses: {misses}
    False Alarms: {false_alarms}
    Correct Rejections: {correct_rejections}
    
    Hit Rate: {raw_hit_rate:.2f}
    False Alarm Rate: {raw_false_alarm_rate:.2f}
    
    d-prime (d′): {d_prime:.2f}
    Response Bias (c): {criterion_c:.2f}
    F1-score: {f1_score:.2f}
    
    Press SPACE to continue"""
    text_Results.setText(results_text)
    # create starting attributes for key_Results
    key_Results.keys = []
    key_Results.rt = []
    _key_Results_allKeys = []
    # store start times for Results
    Results.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Results.tStart = globalClock.getTime(format='float')
    Results.status = STARTED
    thisExp.addData('Results.started', Results.tStart)
    Results.maxDuration = None
    # keep track of which components have finished
    ResultsComponents = Results.components
    for thisComponent in Results.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Results" ---
    thisExp.currentRoutine = Results
    Results.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_Results* updates
        
        # if text_Results is starting this frame...
        if text_Results.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_Results.frameNStart = frameN  # exact frame index
            text_Results.tStart = t  # local t and not account for scr refresh
            text_Results.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_Results, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_Results.started')
            # update status
            text_Results.status = STARTED
            text_Results.setAutoDraw(True)
        
        # if text_Results is active this frame...
        if text_Results.status == STARTED:
            # update params
            pass
        
        # *key_Results* updates
        waitOnFlip = False
        
        # if key_Results is starting this frame...
        if key_Results.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_Results.frameNStart = frameN  # exact frame index
            key_Results.tStart = t  # local t and not account for scr refresh
            key_Results.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_Results, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_Results.started')
            # update status
            key_Results.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_Results.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_Results.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_Results.status == STARTED and not waitOnFlip:
            theseKeys = key_Results.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_Results_allKeys.extend(theseKeys)
            if len(_key_Results_allKeys):
                key_Results.keys = _key_Results_allKeys[-1].name  # just the last key pressed
                key_Results.rt = _key_Results_allKeys[-1].rt
                key_Results.duration = _key_Results_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Results,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Results.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Results.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Results.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Results" ---
    for thisComponent in Results.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Results
    Results.tStop = globalClock.getTime(format='float')
    Results.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Results.stopped', Results.tStop)
    # check responses
    if key_Results.keys in ['', [], None]:  # No response was made
        key_Results.keys = None
    thisExp.addData('key_Results.keys',key_Results.keys)
    if key_Results.keys != None:  # we had a response
        thisExp.addData('key_Results.rt', key_Results.rt)
        thisExp.addData('key_Results.duration', key_Results.duration)
    thisExp.nextEntry()
    # the Routine "Results" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "ThankYou" ---
    # create an object to store info about Routine ThankYou
    ThankYou = data.Routine(
        name='ThankYou',
        components=[text_thankYou, key_thankYou],
    )
    ThankYou.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_thankYou
    key_thankYou.keys = []
    key_thankYou.rt = []
    _key_thankYou_allKeys = []
    # store start times for ThankYou
    ThankYou.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    ThankYou.tStart = globalClock.getTime(format='float')
    ThankYou.status = STARTED
    thisExp.addData('ThankYou.started', ThankYou.tStart)
    ThankYou.maxDuration = None
    # keep track of which components have finished
    ThankYouComponents = ThankYou.components
    for thisComponent in ThankYou.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "ThankYou" ---
    thisExp.currentRoutine = ThankYou
    ThankYou.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_thankYou* updates
        
        # if text_thankYou is starting this frame...
        if text_thankYou.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_thankYou.frameNStart = frameN  # exact frame index
            text_thankYou.tStart = t  # local t and not account for scr refresh
            text_thankYou.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_thankYou, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_thankYou.started')
            # update status
            text_thankYou.status = STARTED
            text_thankYou.setAutoDraw(True)
        
        # if text_thankYou is active this frame...
        if text_thankYou.status == STARTED:
            # update params
            pass
        
        # *key_thankYou* updates
        waitOnFlip = False
        
        # if key_thankYou is starting this frame...
        if key_thankYou.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_thankYou.frameNStart = frameN  # exact frame index
            key_thankYou.tStart = t  # local t and not account for scr refresh
            key_thankYou.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_thankYou, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_thankYou.started')
            # update status
            key_thankYou.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_thankYou.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_thankYou.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_thankYou.status == STARTED and not waitOnFlip:
            theseKeys = key_thankYou.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_thankYou_allKeys.extend(theseKeys)
            if len(_key_thankYou_allKeys):
                key_thankYou.keys = _key_thankYou_allKeys[-1].name  # just the last key pressed
                key_thankYou.rt = _key_thankYou_allKeys[-1].rt
                key_thankYou.duration = _key_thankYou_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=ThankYou,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            ThankYou.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if ThankYou.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in ThankYou.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "ThankYou" ---
    for thisComponent in ThankYou.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for ThankYou
    ThankYou.tStop = globalClock.getTime(format='float')
    ThankYou.tStopRefresh = tThisFlipGlobal
    thisExp.addData('ThankYou.stopped', ThankYou.tStop)
    # check responses
    if key_thankYou.keys in ['', [], None]:  # No response was made
        key_thankYou.keys = None
    thisExp.addData('key_thankYou.keys',key_thankYou.keys)
    if key_thankYou.keys != None:  # we had a response
        thisExp.addData('key_thankYou.rt', key_thankYou.rt)
        thisExp.addData('key_thankYou.duration', key_thankYou.duration)
    thisExp.nextEntry()
    # the Routine "ThankYou" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    # stop any playback components
    if thisExp.currentRoutine is not None:
        for comp in thisExp.currentRoutine.getPlaybackComponents():
            comp.stop()
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
